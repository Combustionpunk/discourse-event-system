# frozen_string_literal: true

module DiscourseEventSystem
  class BookingsController < ApplicationController
    before_action :ensure_logged_in
    before_action :set_booking, only: [:show, :confirm, :cancel, :refund, :add_classes]

    def index
      bookings = DesEventBooking.where(user_id: current_user.id)
        .includes(:event, :booking_classes)
        .select { |b| b.event.present? }
      render json: serialize_bookings(bookings)
    end

    def eligible_cars
      event = DesEvent.find(params[:event_id])
      class_ids = params[:class_ids].is_a?(Array) ? params[:class_ids] : params[:class_ids].values

      # Admin can fetch cars for a specific user
      target_user_id = if current_user.admin? && params[:user_id].present?
        params[:user_id].to_i
      else
        current_user.id
      end

      # Collect cars from target user and their family members
      family_user_ids = []
      family_usernames = {}

      DesRacingFamilyMember.for_guardian(target_user_id).includes(:user).each do |fm|
        family_user_ids << fm.user_id
        family_usernames[fm.user_id] = fm.user.username
      end

      DesRacingFamilyMember.for_child(target_user_id).includes(:guardian).each do |fm|
        family_user_ids << fm.guardian_user_id
        family_usernames[fm.guardian_user_id] = fm.guardian.username
      end

      all_user_ids = ([target_user_id] + family_user_ids).uniq
      all_cars = DesUserCar.where(user_id: all_user_ids)
        .includes(:manufacturer, :car_model, :class_type, :user)
        .active

      result = class_ids.map do |class_id|
        event_class = DesEventClass.find(class_id)
        eligible = all_cars.select { |car| car.eligible_for_class?(event_class) }
        {
          class_id: class_id,
          class_name: event_class.name,
          eligible_cars: eligible.map { |car|
            owner = car.user_id == target_user_id ? nil : (family_usernames[car.user_id] || car.user&.username)
            {
              id: car.id,
              friendly_name: car.display_name,
              driveline: car.effective_driveline,
              transponder_number: car.transponder_number,
              model: car.car_model&.name || car.custom_model_name,
              model_status: car.car_model&.status,
              owner_username: owner
            }
          }
        }
      end

      render json: { classes: result }
    end
    def show
      ensure_booking_owner!
      render json: serialize_booking(@booking)
    end

    def create
      event = DesEvent.find(params[:event_id])
      service = DesBookingService.new(current_user, event)

      if params[:family_bookings].present?
        family_bookings = params[:family_bookings].values.map do |fb|
          { user_id: fb[:user_id].to_i, class_ids: fb[:class_ids] }
        end
        # Validate family members: must be in org membership OR guardian relationship
        allowed_ids = Set.new

        membership = DesOrganisationMembership
          .where(user_id: current_user.id, organisation_id: event.organisation_id)
          .active
          .joins(:family_members)
          .first
        allowed_ids.merge(membership.family_members.pluck(:user_id)) if membership

        # Guardian relationship
        allowed_ids.merge(DesRacingFamilyMember.for_guardian(current_user.id).pluck(:user_id))

        family_bookings.each do |fb|
          raise Discourse::InvalidAccess unless allowed_ids.include?(fb[:user_id])
        end

        result = service.create_family_booking(params[:class_ids], family_bookings, params[:car_selections])
      else
        result = service.create_booking(params[:class_ids], params[:car_selections])
      end

      render json: {
        booking: serialize_booking(result[:booking]),
        approval_url: result[:approval_url]
      }, status: :created
    rescue Discourse::InvalidAccess
      render json: { error: "You do not have permission to book for these users" }, status: :forbidden
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end

    def confirm
      ensure_booking_owner!
      service = DesBookingService.new(current_user, @booking.event)
      service.confirm_booking(@booking, params[:paypal_order_id])
      render json: serialize_booking(@booking.reload)
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end

    def cancel
      ensure_booking_owner!
      service = DesBookingService.new(current_user, @booking.event)
      service.cancel_booking(@booking)
      render json: serialize_booking(@booking.reload)
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end

    def refund
      ensure_booking_owner!
      service = DesBookingService.new(current_user, @booking.event)
      service.refund_booking(@booking, current_user, params[:reason])
      render json: serialize_booking(@booking.reload)
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end

    def join_waitlist
      event = DesEvent.find(params[:event_id])
      event_class = DesEventClass.find(params[:event_class_id])

      # Check if already on waitlist
      existing = DesEventWaitlist.find_by(
        event_class_id: event_class.id,
        user_id: current_user.id,
        status: 'waiting'
      )
      return render json: { error: 'Already on waitlist' }, status: :unprocessable_entity if existing

      # Check if class has spaces - if it does, no need to join waitlist
      if event_class.spaces_remaining > 0 && event_class.status != 'sold_out'
        return render json: { error: 'Class still has spaces available - please book directly' }, status: :unprocessable_entity
      end

      waitlist_entry = DesEventWaitlist.add_to_waitlist(event, event_class, current_user)
      render json: {
        id: waitlist_entry.id,
        position: waitlist_entry.position,
        class_name: event_class.name,
        status: waitlist_entry.status
      }, status: :created
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end

    def leave_waitlist
      entry = DesEventWaitlist.find_by(id: params[:id], user_id: current_user.id)
      return render json: { error: 'Not found' }, status: :not_found unless entry
      entry.expire!
      render json: { success: true }
    end

    def my_waitlist
      entries = DesEventWaitlist.where(user_id: current_user.id)
        .where(status: ['waiting', 'notified'])
        .includes(:event, :event_class)
      render json: {
        waitlist: entries.select { |e| e.event.present? }.map { |e|
          {
            id: e.id,
            event: { id: e.event.id, title: e.event.title, start_date: e.event.start_date },
            class_name: e.event_class&.name || 'Unknown',
            position: e.position,
            status: e.status
          }
        }
      }
    end

    def add_classes
      ensure_booking_owner!
      service = DesBookingService.new(current_user, @booking.event)
      result = service.add_classes(@booking, params[:class_ids])
      render json: {
        booking: serialize_booking(result[:booking].reload),
        approval_url: result[:approval_url]
      }
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end


    def change_car
      booking = DesEventBooking.find(params[:id])
      # Must own booking or be guardian of booking user
      unless booking.user_id == current_user.id ||
             DesRacingFamilyMember.exists?(user_id: booking.user_id, guardian_user_id: current_user.id)
        raise Discourse::InvalidAccess
      end
      bc = booking.booking_classes.find(params[:class_id])
      car = DesUserCar.find(params[:car_id])
      bc.update!(car_id: car.id, transponder_number: car.transponder_number)
      render json: { success: true }
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end

    def my_bookings_with_dependants
      user_ids = [current_user.id]
      DesRacingFamilyMember.for_guardian(current_user.id).pluck(:user_id).each { |id| user_ids << id }

      bookings = DesEventBooking.where(user_id: user_ids)
        .includes(:user, :event, booking_classes: [{ event_class: :class_type }, { user_car: [:manufacturer, :car_model] }])
        .select { |b| b.event.present? }
        .sort_by { |b| b.event.start_date }.reverse

      render json: {
        bookings: bookings.map { |b|
          {
            id: b.id,
            username: b.user&.username,
            is_own: b.user_id == current_user.id,
            event: {
              id: b.event.id,
              title: b.event.title,
              start_date: b.event.start_date,
              location: b.event.location,
              organisation_name: b.event.organisation&.name,
              status: b.event.status
            },
            status: b.status,
            amount_paid: b.amount_paid,
            classes: b.booking_classes.map { |bc|
              car = bc.user_car
              {
                id: bc.id,
                class_name: bc.event_class&.class_type&.name || bc.event_class&.name || 'Unknown',
                event_class_id: bc.event_class_id,
                status: bc.status,
                transponder_number: bc.transponder_number,
                manufacturer_name: car&.manufacturer&.name,
                model_name: car&.car_model&.name || car&.custom_model_name,
                car_id: bc.car_id
              }
            }
          }
        }
      }
    end

    private

    def set_booking
      @booking = DesEventBooking.find(params[:id])
    end

    def ensure_booking_owner!
      raise Discourse::InvalidAccess unless @booking.user_id == current_user.id ||
        @booking.booked_by_user_id == current_user.id ||
        current_user.admin?
    end

    def serialize_booking(booking)
      event = booking.event
      {
        id: booking.id,
        event: event ? {
          id: event.id,
          title: event.title,
          start_date: event.start_date,
          location: event.location,
          topic_url: event.topic&.url
        } : nil,
        status: booking.status,
        total_amount: booking.total_amount,
        discount_amount: booking.discount_amount,
        amount_paid: booking.amount_paid,
        brca_membership_number: booking.brca_membership_number,
        classes: booking.booking_classes.map do |bc|
          {
            id: bc.id,
            class_name: bc.event_class&.name || 'Unknown',
            status: bc.status,
            amount_charged: bc.amount_charged,
            transponder_number: bc.transponder_number,
            transponder_overridden: bc.transponder_overridden
          }
        end,
        payments: booking.payments.map do |p|
          {
            id: p.id,
            amount: p.amount,
            status: p.status,
            payment_type: p.payment_type,
            created_at: p.created_at
          }
        end
      }
    end

    def serialize_bookings(bookings)
      bookings.map { |b| serialize_booking(b) }
    end
  end
end
